<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 */
?>
		</div><!-- #content -->
<?php global $hideFooter; if (!$hideFooter) { ?>
        <footer class="u-align-center u-black u-clearfix u-footer u-footer" id="sec-a6bd">
  <div class="u-clearfix u-sheet u-sheet-1">
    <?php $logo = theme_get_logo(array(
            'default_src' => "/images/logo.jpg",
            'default_url' => "[page_754507976]#sec-4dda"
        )); $url = stripos($logo['url'], 'http') === 0 ? esc_url($logo['url']) : $logo['url']; ?><a <?php if (is_customize_preview()) echo 'data-default-src="' . esc_url($logo['default_src']) . '" '; ?>href="<?php echo $url; ?>" class="u-image u-logo u-image-1 custom-logo-link" data-image-width="128" data-image-height="128" title="Página Inicial">
      <img <?php if ($logo['svg']) { echo 'style="width:'.$logo['width'].'px"'; } ?>src="<?php echo esc_url($logo['src']); ?>" class="u-logo-image u-logo-image-1" data-image-width="125.154">
    </a>
    <div class="u-social-icons u-spacing-37 u-social-icons-1">
      <a class="u-social-url" title="facebook" target="_blank" href="https://facebook.com/assunsound"><span class="u-icon u-icon-circle u-social-facebook u-social-icon u-icon-1"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 512 512" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-321a"></use></svg><svg class="u-svg-content" viewBox="0 0 512 512" id="svg-321a"><path d="m483.738281 0h-455.5c-15.597656.0078125-28.24218725 12.660156-28.238281 28.261719v455.5c.0078125 15.597656 12.660156 28.242187 28.261719 28.238281h455.476562c15.605469.003906 28.257813-12.644531 28.261719-28.25 0-.003906 0-.007812 0-.011719v-455.5c-.007812-15.597656-12.660156-28.24218725-28.261719-28.238281zm0 0" fill="currentColor"></path><path d="m353.5 512v-198h66.75l10-77.5h-76.75v-49.359375c0-22.386719 6.214844-37.640625 38.316406-37.640625h40.683594v-69.128906c-7.078125-.941406-31.363281-3.046875-59.621094-3.046875-59 0-99.378906 36-99.378906 102.140625v57.035156h-66.5v77.5h66.5v198zm0 0" fill="#fff"></path></svg></span>
      </a>
      <a class="u-social-url" title="instagram" target="_blank" href="https://instagram.com/assunsound"><span class="u-icon u-icon-circle u-social-icon u-social-instagram u-icon-2"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 512 512" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-aa89"></use></svg><svg class="u-svg-content" viewBox="0 0 512 512" x="0px" y="0px" id="svg-aa89" style="enable-background:new 0 0 512 512;"><path style="fill:#795548;" d="M512,74.667V160H0V74.667C0,33.429,33.429,0,74.667,0h362.667C478.571,0,512,33.429,512,74.667  L512,74.667z"></path><path style="fill:#BDBDBD;" d="M512,160v277.333C512,478.571,478.571,512,437.333,512H74.667C33.429,512,0,478.571,0,437.333V160  H512z"></path><path style="fill:#37474F;" d="M373.333,42.667h64c5.891,0,10.667,4.776,10.667,10.667v64c0,5.891-4.776,10.667-10.667,10.667h-64  c-5.891,0-10.667-4.776-10.667-10.667v-64C362.667,47.442,367.442,42.667,373.333,42.667z"></path><path style="fill:#F44336;" d="M53.333,106.667c-5.891,0-10.667-4.776-10.667-10.667V21.333c0-5.891,4.776-10.667,10.667-10.667  S64,15.442,64,21.333V96C64,101.891,59.224,106.667,53.333,106.667z"></path><path style="fill:#FFC107;" d="M96,106.667c-5.891,0-10.667-4.776-10.667-10.667V10.667C85.333,4.776,90.109,0,96,0  c5.891,0,10.667,4.776,10.667,10.667V96C106.667,101.891,101.891,106.667,96,106.667z"></path><path style="fill:#4CAF50;" d="M138.667,106.667C132.776,106.667,128,101.891,128,96V10.667C128,4.776,132.776,0,138.667,0  s10.667,4.776,10.667,10.667V96C149.333,101.891,144.558,106.667,138.667,106.667z"></path><circle style="fill:#455A64;" cx="256" cy="256" r="117.333"></circle><path style="fill:#8D6E63;" d="M256,384c-70.692,0-128-57.308-128-128s57.308-128,128-128s128,57.308,128,128  C383.918,326.658,326.658,383.918,256,384z M256,149.333c-58.91,0-106.667,47.756-106.667,106.667S197.09,362.667,256,362.667  S362.667,314.91,362.667,256C362.596,197.119,314.881,149.404,256,149.333z"></path><circle style="fill:#37474F;" cx="256" cy="256" r="64"></circle></svg></span>
      </a>
      <a class="u-social-url" target="_blank" title="Email" href="mailto:jamil@assunsound.com.br"><span class="u-icon u-icon-circle u-social-email u-social-icon u-icon-3"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 512 512" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-a7f6"></use></svg><svg class="u-svg-content" viewBox="0 0 512 512" x="0px" y="0px" id="svg-a7f6" style="enable-background:new 0 0 512 512;"><path style="fill:#64B5F6;" d="M0,192l246.528,156.896c2.816,2.08,6.144,3.104,9.472,3.104s6.656-1.024,9.472-3.104L512,192  L265.6,3.2c-5.696-4.256-13.504-4.256-19.2,0L0,192z"></path><path style="fill:#ECEFF1;" d="M416,0H96C78.368,0,64,14.368,64,32v352c0,8.832,7.168,16,16,16h352c8.832,0,16-7.168,16-16V32  C448,14.368,433.664,0,416,0z"></path><g><path style="fill:#90A4AE;" d="M144,96h224c8.832,0,16-7.168,16-16s-7.168-16-16-16H144c-8.832,0-16,7.168-16,16S135.168,96,144,96   z"></path><path style="fill:#90A4AE;" d="M368,128H144c-8.832,0-16,7.168-16,16s7.168,16,16,16h224c8.832,0,16-7.168,16-16   S376.832,128,368,128z"></path><path style="fill:#90A4AE;" d="M272,192H144c-8.832,0-16,7.168-16,16s7.168,16,16,16h128c8.832,0,16-7.168,16-16   S280.832,192,272,192z"></path>
</g><path style="fill:#1E88E5;" d="M265.472,348.896c-2.816,2.08-6.144,3.104-9.472,3.104s-6.656-1.024-9.472-3.104L0,192v288  c0,17.664,14.336,32,32,32h448c17.664,0,32-14.336,32-32V192L265.472,348.896z"></path><path style="fill:#2196F3;" d="M480,512H32c-17.952,0-32-14.048-32-32c0-5.088,2.432-9.888,6.528-12.896l240-160  c2.816-2.08,6.144-3.104,9.472-3.104s6.656,1.024,9.472,3.104l240,160C509.568,470.112,512,474.912,512,480  C512,497.952,497.952,512,480,512z"></path></svg></span>
      </a>
    </div>
    <h6 class="u-custom-font u-font-arial u-text u-text-1">COPYRIGHT 2021 - Criado por Phablo Souza</h6>
  </div>
</footer>
        
<?php } ?>
        <?php $showBackLink = get_option('np_hide_backlink') ? false : true; ?>
<?php if ($showBackLink) : $GLOBALS['theme_backlink'] = true; ?>
<section class="u-backlink u-clearfix u-grey-80">
            <a class="u-link" href="https://localhost/WordPress Themes" target="_blank">
        <span>wordpress-themes</span>
            </a>
        <p class="u-text"><span>created with</span></p>
        <a class="u-link" href="https://localhost/wordpress-website-builder" target="_blank"><span>WordPress Website Builder</span></a>.
    </section>
<?php endif; ?>
        
	</div><!-- .site-inner -->
</div><!-- #page -->

<?php wp_footer(); ?>
<?php back_to_top(); ?>
</body>
</html>
