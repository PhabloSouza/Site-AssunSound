<!-- post styles -->

<style>.u-section-1 .u-sheet-1 {
  min-height: 279px;
}
.u-section-1 .u-text-1 {
  margin-left: auto;
  margin-right: auto;
  font-size: 1.875rem;
}
@media (max-width: 767px) {
  .u-section-1 .u-text-1 {
    margin-top: 60px;
    margin-bottom: 60px;
  }
}
</style>
