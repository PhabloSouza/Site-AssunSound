<!-- footer styles -->

<style>.u-footer {
  background-image: none;
}
.u-footer .u-sheet-1 {
  min-height: 121px;
}
.u-footer .u-image-1 {
  margin: 11px auto 0 37px;
}
.u-footer .u-logo-image-1 {
  max-width: 99px;
  max-height: 99px;
}
.u-footer .u-social-icons-1 {
  height: 50px;
  min-height: 16px;
  width: 224px;
  min-width: 122px;
  margin: -74px 37px 0 auto;
}
.u-footer .u-icon-1 {
  color: rgb(66, 103, 178) !important;
}
.u-footer .u-icon-2 {
  color: rgb(255, 255, 255) !important;
}
.u-footer .u-icon-3 {
  height: 100%;
  color: rgb(255, 255, 255) !important;
}
.u-footer .u-text-1 {
  margin: -36px 408px 50px 357px;
}
@media (max-width: 1199px) {
  .u-footer .u-sheet-1 {
    min-height: 134px;
  }
  .u-footer .u-image-1 {
    width: auto;
    margin-top: 6px;
    margin-left: 0;
  }
  .u-footer .u-social-icons-1 {
    margin-right: 0;
  }
  .u-footer .u-text-1 {
    width: 363px;
    margin: -35px auto 60px;
  }
}
@media (max-width: 991px) {
  .u-footer .u-sheet-1 {
    min-height: 304px;
  }
  .u-footer .u-image-1 {
    width: 126px;
    margin-top: 0;
    margin-left: auto;
  }
  .u-footer .u-logo-image-1 {
    max-width: 125px;
    max-height: 125px;
  }
  .u-footer .u-social-icons-1 {
    width: 262px;
    height: 63px;
    margin-top: 24px;
    margin-right: auto;
  }
  .u-footer .u-text-1 {
    width: 365px;
    margin-top: 36px;
    margin-bottom: 36px;
  }
}
@media (max-width: 767px) {
  .u-footer .u-sheet-1 {
    min-height: 369px;
  }
  .u-footer .u-image-1 {
    margin-top: 2px;
    width: auto;
  }
  .u-footer .u-social-icons-1 {
    width: 261px;
    margin-top: 53px;
  }
  .u-footer .u-text-1 {
    width: 365px;
    margin-top: 53px;
    margin-bottom: 53px;
  }
}
@media (max-width: 575px) {
  .u-footer .u-sheet-1 {
    min-height: 389px;
  }
  .u-footer .u-image-1 {
    margin-top: 47px;
    width: 126px;
  }
  .u-footer .u-social-icons-1 {
    width: 210px;
    height: 45px;
    margin-top: 31px;
  }
  .u-footer .u-text-1 {
    width: auto;
    margin: 47px 0 51px;
  }
}</style>
