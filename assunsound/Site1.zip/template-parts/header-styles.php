<!-- header styles -->

<link id="u-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
<style>.u-header {
  background-image: linear-gradient(black, #77aad9);
}
.u-header .u-sheet-1 {
  min-height: 123px;
}
.u-header .u-image-1 {
  animation-duration: 1000ms;
  box-shadow: -2px -2px 8px 0 rgba(26,26,26,1);
  margin: 18px auto 0 26px;
}
.u-header .u-logo-image-1 {
  max-width: 100px;
  max-height: 100px;
}
.u-header .u-social-icons-1 {
  height: 35px;
  min-height: 16px;
  width: 152px;
  min-width: 94px;
  margin: -76px 44px 0 auto;
}
.u-header .u-icon-1 {
  color: rgb(255, 255, 255) !important;
}
.u-header .u-icon-3 {
  color: rgb(255, 255, 255) !important;
}
.u-header .u-menu-1 {
  margin: -28px auto 36px;
}
.u-header .u-nav-1 {
  font-size: 1rem;
  letter-spacing: 0px;
  text-transform: none;
  font-weight: 700;
}
.u-block-904f-21 {
  font-size: 1rem;
  letter-spacing: 0px;
  font-weight: 700;
  text-transform: none;
}
.u-header .u-nav-2 {
  font-size: 1rem;
  letter-spacing: 0px;
  font-weight: 700;
  text-transform: none;
}
.u-block-904f-22 {
  font-size: 1rem;
  letter-spacing: 0px;
  font-weight: 700;
  text-transform: none;
}
@media (max-width: 1199px) {
  .u-header .u-image-1 {
    margin-left: 26px;
  }
  .u-header .u-social-icons-1 {
    width: 152px;
    margin-right: 44px;
  }
  .u-header .u-menu-1 {
    margin-top: -28px;
  }
}
@media (max-width: 991px) {
  .u-header .u-sheet-1 {
    min-height: 171px;
  }
  .u-header .u-image-1 {
    width: auto;
    margin-top: 35px;
    margin-left: 51px;
  }
  .u-header .u-social-icons-1 {
    margin-top: -69px;
    margin-right: 0;
  }
  .u-header .u-menu-1 {
    margin-top: -36px;
    margin-bottom: 60px;
  }
}
@media (max-width: 767px) {
  .u-header .u-sheet-1 {
    min-height: 234px;
  }
  .u-header .u-image-1 {
    margin-top: 19px;
    margin-left: auto;
    width: auto;
  }
  .u-header .u-logo-image-1 {
    max-width: 88px;
    max-height: 88px;
  }
  .u-header .u-social-icons-1 {
    margin-top: 71px;
    margin-right: auto;
  }
  .u-header .u-menu-1 {
    margin-top: -87px;
  }
}
@media (max-width: 575px) {
  .u-header .u-sheet-1 {
    min-height: 264px;
  }
  .u-header .u-image-1 {
    margin-top: 36px;
    width: auto;
  }
  .u-header .u-logo-image-1 {
    max-width: 105px;
    max-height: 105px;
  }
  .u-header .u-social-icons-1 {
    width: 229px;
    height: 61px;
    margin-top: 27px;
    margin-right: 38px;
  }
  .u-header .u-menu-1 {
    margin-top: 24px;
    margin-bottom: 24px;
  }
}</style>
